//=p-Clase Principal
#include <iostream>
#include "simpson.h"
#include <iomanip>

simpson P;

using namespace std;

//=i
void pideVals()
{
    P.SetX();
    P.SetDof();
    P.SetNumeroSegmentos(10);
    P.SetE(0.0000001);
}

//=i
void imprime()
{
    cout << " X = " << setprecision(5) << fixed << P.X << endl;
    cout << " Dof = " << setprecision(5) << fixed << P.Dof << endl;
    cout << " P = " << setprecision(5) << fixed << P.P2 << endl;
}

int main()
{
    pideVals();
    P.GetP();
    imprime();
    return 0;
}
