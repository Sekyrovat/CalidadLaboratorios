//Hector Hernandez Morales
//Ultima Modificacion = 14/11/2017
//=p-LinkedList
//=b-55
#ifndef linkedlist_h
#define linkedlist_h

#include "NodoDePartes.h"
using namespace std;
class linkedlist
{
private:
    //Apuntador al primer elemento de la lista
    NodoDePartes* head;
    //Variable de control para ver el tamanio de la lista
    int length;
    //Variable para ver si hay elementos en la lista
    bool isEmpty();
    //Funcio nde destructor
    void borra();
    //Funcion para agregar un nodo al inicio
    void addFirst(NodoDePartes nAuxiliar);

public:
    //Constructor Vacio
    linkedlist();
    //Destructor
    ~linkedlist();
    //Funcion para obtener el tamanio
    int getlength();

    //Funcion para agregar continuamente en lo que se recorre la lista.
    void add(NodoDePartes nodex);
    NodoDePartes* getNode(int pos);

    //Funcion para obtener el HEAD de la lista
    NodoDePartes* gethead();

};

//=i
//Funcion de inicializacion de una linkedlist vacia
linkedlist::linkedlist()
{
    //Se establece que no se apunta a un valor nulo para estar vacio
    head = NULL;
    //No tiene tamanio
    length = 0;
}

//=i
//Funcion para obtener el tamanio.
int linkedlist::getlength()
{
    //Se regresa el taamnio
    return this->length;
}

//=i
bool linkedlist::isEmpty()
{
    return (head == NULL);
}

//=i
//Funcion para borrar toda la lista
void linkedlist::borra()
{
    //Se crea un nodo auxiliar que recorre toda la lista hasta elimanr todo
    NodoDePartes *aux = head;
    while (head != NULL)
    {
        head = head->getNext();
        delete aux;
        aux = head;
    }
}

//=i
//Destructor de la Linked List
linkedlist::~linkedlist()
{
    borra();
}

//=i
//Esta funcion es usada para agregar el primer nodo a la lista
void linkedlist::addFirst(NodoDePartes node)
{
    head = new NodoDePartes(node.getDW(), node.getDX() , node.getDY(), node.getDZ());//=m
    length++;
}

//=i
//Agrega un elemento al final de la lista
void linkedlist::add(NodoDePartes nodex)
{
    //Verificamos si esta vacia
    if (this->isEmpty())
    {
        //Si si agregamos el nodo como primer elemento
        this->addFirst(nodex);
    }
    else
    {
        NodoDePartes *aux = head;

        //Nos posicionamos en el ultimo nodo.
        while (aux->getNext() != NULL)
        {
            aux = aux->getNext();
        }
        //Le asignamos un siguiente nodo al antiguo final, cuyo next vale Null.
        aux->setNext(new NodoDePartes(nodex.getDW(), nodex.getDX() , nodex.getDY(), nodex.getDZ()));//=m
        length++;
    }
}

//=i
//Funcion para regresar el nodo del cual obtendremos los valores en la clase main.
NodoDePartes* linkedlist::getNode(int pos)
{
    //Vemos si s una posicion valida la que see pide.
    if(pos < 0 || pos >= this->length)
    {
        return NULL;
    }
    else
    {
        //Auxiliar que se usara para recorrer la lista.
        NodoDePartes *nodex = head;

        //Recorremos la lista en busca del nodo.
        for(int i = 0; i < pos; i++)
        {
            nodex = nodex->getNext();
        }
        return nodex;
    }
}

#endif
