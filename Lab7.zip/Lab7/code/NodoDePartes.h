//Hector Hernandez Morales
//Ultima Modificacion = 14/11/2017
//=p-Nodo
//=b-44
#ifndef NodoDePartes_H
#define NodoDePartes_H

#include <iostream>
using namespace std;
class NodoDePartes
{
    public:
        //Constructor sin parametros
        NodoDePartes ();
        //Constructor con parametros pero sin next
        NodoDePartes (double dWT, double dXT, double dYT, double dZT);//=m
        //Constructor con parametros con next
        NodoDePartes (double dWT, double dXT, double dYT, double dZT, NodoDePartes* next1);//=m

        //Metodo para obtener el siguiente nodo
        NodoDePartes* getNext();

        //Ambos metodos sirven para obtener el valor de x y de y
        double getDX();
        double getDY();
        double getDW();
        double getDZ();

        //Metodos para ponerle valores a x y y
        void setDX(double dXTemp);
        void setDY(double dYTemp);
        void setDW(double dWTemp);
        void setDZ(double dZTemp);

        //=i
        //Metodo para setear el siguiente nodo
        //Debido a un error de compilacion que se ha presnetado desde el uso de la primera lista se declara y escribe dentro de la declaracion.
        void setNext(NodoDePartes* newNode)
        {
            next = newNode;
        }

        //Declaracion de las variables que tendra el nodo, donde cada nodo evaluara a una parte.
    private:
        //Apuntador al siguiente nodo
        NodoDePartes *next;
        //Valores de x y y para caa punto.
        double dW;
        double dX;
        double dY;
        double dZ;
};

//=i
//Constructor vacio
NodoDePartes::NodoDePartes()
{
    dW = 0.0;
    dX = 0.0;
    dY = 0.0;
    dZ = 0.0;
    next = NULL;
}

//=i
//Constructor con parametros pero sin next
NodoDePartes::NodoDePartes(double dWT, double dXT, double dYT, double dZT)//=m
{
    dW = dWT;
    dX = dXT;
    dY = dYT;
    dZ = dZT;
    next = NULL;
}

//=i
//Constructor con parametros y next
NodoDePartes::NodoDePartes(double dWT, double dXT, double dYT, double dZT, NodoDePartes* next1)//=m
{
    dW = dWT;
    dX = dXT;
    dY = dYT;
    dZ = dZT;
    next = next1;
}



//Ambos metodos sirven para obtener el valor de x y de y
double NodoDePartes::getDX()
{
    return dX;
}
double NodoDePartes::getDY()
{
    return dY;
}
double NodoDePartes::getDW()
{
    return dW;
}
double NodoDePartes::getDZ()
{
    return dZ;
}


 //Metodos para ponerle valores a x y y
void NodoDePartes::setDX(double dXTemp)
{
    dX = dXTemp;
}

void NodoDePartes::setDY(double dYTemp)
{
    dY = dYTemp;
}
void NodoDePartes::setDW(double dWTemp)
{
    dW = dWTemp;
}

void NodoDePartes::setDZ(double dZTemp)
{
    dZ = dZTemp;
}

//=i
//Metodo para obtener el siguiente nodo
NodoDePartes* NodoDePartes::getNext()
{
    return next;
}

#endif
