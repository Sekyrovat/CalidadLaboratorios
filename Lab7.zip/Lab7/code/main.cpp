//Hector Hernandez Morales
//Ultima Modificacion = 14/11/2017
//=p-Clase principal
//=b-104

//Importamos las librerias que son de utilidad
#include <iostream>
#include <string>
#include <fstream>
#include <stdio.h>
#include <iomanip>
#include <math.h>
#include <string.h>
#include <stdlib.h>     /* atof */
#include "linkedlist.h"
#include "NodoDePartes.h"
#include "Gauss.h"


using namespace std;

//Variable para almacenar el tamanio de la lista.
int iTamanio = 0;

//=d-12

//=i
//Funcion para validar que el archivo que se solicito abrir exista.
string funcValidadorDeNombres(string sNom)
{
    ifstream arch(sNom.c_str());
    //Aqui verificamos si el archivo existe o no
    while(!arch.good())
    {
        //Ci no existe pedimos se ingrese otra vez el nombre
        cout<<"Archivo inexistente! Ingrese otro nombre:";
        getline(cin, sNom);
        ifstream arch(sNom.c_str());

        //Si encutra el nombre del archivo lo refresa.
        if(arch.good())
        {
            return sNom;
        }
    }
    //Regresa el nombre del archivo que encontro
    return sNom;
}

//=i
//=d-26

//=i
//Funcion para calcular el valor de Zk por medio de la formula.
void Calcula(double dWk, double dXk, double dYk, Gauss gaussCalcula, double &dZk)//=m
{
    dZk = gaussCalcula.dB0 + dWk* gaussCalcula.dB1 + dXk* gaussCalcula.dB2 + dYk* gaussCalcula.dB3;//=m
}

//=i
//=d-6
//Funcion para imrpimir todos los valores que se nos han solicitado.
void Imprime(int iTamanio, double dWk, double dXk, double dYk, Gauss gaussCalcula, double dZk)//=m
{
    cout << "N= "  << iTamanio << endl; //=m
    cout << "Wk= " << setprecision(5) << fixed << dWk << endl;
    cout << "Xk= " << setprecision(5) << fixed << dXk << endl;
    cout << "Yk= " << setprecision(5) << fixed << dYk << endl;
    cout << " -----------------------------------" << endl;
    cout << "B0= " << setprecision(5) << fixed << gaussCalcula.dB0<< endl;
    cout << "B1= " << setprecision(5) << fixed << gaussCalcula.dB1 << endl;
    cout << "B2= " << setprecision(5) << fixed << gaussCalcula.dB2 << endl;
    cout << "B3= " << setprecision(5) << fixed << gaussCalcula.dB3 << endl;
    cout << " -----------------------------------" << endl;
    cout << "Zk= " << setprecision(5) << fixed << dZk << endl;
}

int main()
{
	//Seccion de declaracion de variables

	//Variables para almacenar los primeros tres valores que se leen del archivo.
    double dWk = 0.0;
    double dXk = 0.0;
    double dYk = 0.0;

    //Variable auxiliar de nodo
    NodoDePartes Nodo;
    //Lista para nodos auxiliares
    linkedlist listaDeDatos;
    //Variable para accessar a los metodos de Gauss.
    Gauss gaussCalcula;
    //Variabel donde se almacenara el resultado del calculo principal.
    double dZk = 0.0;

    //Variables de las sumatorias.
    double dSumatoriaWi = 0.0;
    double dSumatoriaXi = 0.0;
    double dSumatoriaYi = 0.0;
    double dSumatoriaZi = 0.0;
    double dSumatoriaWiAlCuadrado = 0.0;
    double dSumatoriaXiAlCuadrado = 0.0;
    double dSumatoriaYiAlCuadrado = 0.0;
    double dSumatoriaWiPorYi = 0.0;
    double dSumatoriaWiPorZi = 0.0;
    double dSumatoriaWiPorXi = 0.0;
    double dSumatoriaXiPorYi = 0.0;
    double dSumatoriaXiPorZi = 0.0;
    double dSumatoriaYiPorZi = 0.0;

    //Variable para el manejo de los archivos de texto que se usaran.
    ifstream ifArchivo;

    //Variable para la linea que se va a procesar. Variable para almacenar el nombre del archivo.
    string sLinea = "";

	//=d-17

    //Variable de tamanio para marcar donde se encuentra cada coma de las lineas.
    size_t foundPrimeraComa;
    size_t foundSegundaComa;
    size_t foundTerceraComa;

    //Varaiable para controlar el que haya datos o no
    bool validador = true;//=m

    //Pedimos el nombre del archivo a abrir.
    cout << "Ingresa el nombre del archivo" << endl;
    getline(cin, sLinea);

    //Validamos que el archivo exista
    sLinea = funcValidadorDeNombres(sLinea);

    //Lo abrimos, pero como es string usamos la funcion .c_str()
    ifArchivo.open(sLinea.c_str());

    //Obtenemos la primera liena del archivo y seguimos procesando hatsa llegar a la utima la cual tambien se procesa con el mismo while
    //Con el if nos aseguramos que si haya un dato presente y no sea un archivo vacio.
    if(getline(ifArchivo,sLinea))
    {
        //Como sabemos que deben de haber 2 comas con un ciclo nos aseguramos de que se encuentres las 3 comas.
        //Ya que vimos que si encontro todos, encontramos los puntos divisorios
        foundPrimeraComa = sLinea.find(",");
        sLinea.replace(foundPrimeraComa, 1, "P");
        foundSegundaComa = sLinea.find(",");
        sLinea.replace(foundSegundaComa, 1, "S");

        dWk = atof(sLinea.substr(0,foundPrimeraComa).c_str());
        dXk = atof(sLinea.substr(foundPrimeraComa+1,foundSegundaComa-1).c_str());
        dYk = atof(sLinea.substr(foundSegundaComa+1).c_str());

        //Condicional para segurarnos de que lo que se leyo sea valido.
        if(foundPrimeraComa == string::npos || foundSegundaComa == string::npos)
        {
            validador = false;
        }
        else
        {
            validador = true;
        }

    }

    //Si no encontro nada nos salimos del archivo.
    if(validador == false)
    {
        return 0;
    }
    else
    {
        validador = true;
    }

    //Leemos el archivo en busca de puras lineas de informacion.
    while(getline(ifArchivo, sLinea))
    {
        //Ya que vimos que si encontro todos, encontramos los puntos divisorios
        foundPrimeraComa = sLinea.find(",");
        sLinea.replace(foundPrimeraComa, 1, "P");
        foundSegundaComa = sLinea.find(",");
        sLinea.replace(foundSegundaComa, 1, "S");
        foundTerceraComa = sLinea.find(",");
        sLinea.replace(foundSegundaComa, 1, "T");

        //Seteamos los dos valores del nodo auxiliar de acuerdo a las especficaciones y lo agregamos a la lista.
        Nodo.setDW(atof(sLinea.substr(0,foundPrimeraComa).c_str()));
        Nodo.setDX(atof(sLinea.substr(foundPrimeraComa+1,foundSegundaComa-1).c_str()));
        Nodo.setDY(atof(sLinea.substr(foundSegundaComa+1, foundTerceraComa-1).c_str()));
        Nodo.setDZ(atof(sLinea.substr(foundTerceraComa+1).c_str()));
        listaDeDatos.add(Nodo);

        //Condicional para segurarnos de que lo que se leyo sea valido.
        if(foundPrimeraComa == string::npos || foundSegundaComa == string::npos || foundTerceraComa == string::npos)
        {
            validador = false;
        }
        else
        {
            validador = true;
        }
    }

    //Al terminar de procesar el archivo se cierra.
    ifArchivo.close();

    //Si no encontro nada nos salimos del archivo.
    if(validador == false)
    {
        return 0;
    }


    //Le damos el tamanio de la lista a la variable tam.
    iTamanio = listaDeDatos.getlength();


    //Declaracion de variables que seran usadas para almacenar los datos de cada nodo y despues usarlos en la sumatoria.
    double ValX = 0.0;
    double ValY = 0.0;
    double ValW = 0.0;
    double ValZ = 0.0;

    //Auxiliar para almacenar el nodo
    NodoDePartes *nodo;

    for(int i = 0; i < iTamanio; i++)
    {
        //Le asignamos al auxiliar los valores uno a uon de los nodos.
        nodo = listaDeDatos.getNode(i);

        //Cada vez obtenemos el valor del nodo
        ValX = nodo->getDX();
        ValY = nodo->getDY();
        ValW = nodo->getDW();
        ValZ = nodo->getDZ();

        //Vamos haciendo las sumatorias necesarias.
        dSumatoriaWi += ValW;
        dSumatoriaXi += ValX;
        dSumatoriaYi += ValY;
        dSumatoriaZi += ValZ;
        dSumatoriaWiAlCuadrado += pow(ValW,2.0);
        dSumatoriaXiAlCuadrado += pow(ValX,2.0);
        dSumatoriaYiAlCuadrado += pow(ValY,2.0);
        dSumatoriaWiPorYi += ValW * ValY;
        dSumatoriaWiPorZi += ValW * ValZ;
        dSumatoriaWiPorXi += ValW * ValX;
        dSumatoriaXiPorYi += ValX * ValY;
        dSumatoriaXiPorZi += ValX * ValZ;
        dSumatoriaYiPorZi += ValY * ValZ;
    }

    gaussCalcula.ingresaElementos(iTamanio, dSumatoriaWi, dSumatoriaXi, dSumatoriaYi, dSumatoriaZi, dSumatoriaWiAlCuadrado, dSumatoriaXiAlCuadrado, dSumatoriaYiAlCuadrado, dSumatoriaWiPorYi, dSumatoriaWiPorZi, dSumatoriaWiPorXi,dSumatoriaXiPorYi,dSumatoriaXiPorZi,dSumatoriaYiPorZi);

    gaussCalcula.Calcula();

    Calcula(dWk, dXk, dYk, gaussCalcula, dZk);

    Imprime(iTamanio, dWk, dXk, dYk, gaussCalcula, dZk);

	getchar();

    return 0;
}
