//Hector Hernandez Morales
//Ultima Modificacion = 14/11/2017
//=p-Gauss

#include<iostream>
#include<stdio.h>
#include<conio.h>
#include<stdlib.h>

using namespace std;

class Gauss
{
    public:
        //Matriz que se usara para resolver por medio de eliminacion gaussiana.
        double m[4][5];

        //Variable para almacenar el valor de b0 que se calcula.
        double dB0;
        //Variable para almacenar el valor de b1 que se calcula.
        double dB1;
        //Variable para almacenar el valor de b2 que se calcula.
        double dB2;
        //Variable para almacenar el valor de b3 que se calcula.
        double dB3;

        //Connstructor vacio del objeto.
        Gauss();

        //Funcion para setear los datos que se usaran en la matriz.
        //Se mandan las sumatorias y se llenan las casillas de forma manual.
        void ingresaElementos(int iTamanio, double dSumatoriaWi, double dSumatoriaXi, double dSumatoriaYi, double dSumatoriaZi, double dSumatoriaWiAlCuadrado, double dSumatoriaXiAlCuadrado, double dSumatoriaYiAlCuadrado, double dSumatoriaWiPorYi, double dSumatoriaWiPorZi, double dSumatoriaWiPorXi, double dSumatoriaXiPorYi, double dSumatoriaXiPorZi, double dSumatoriaYiPorZi);

        //Esta function tiene como objetivo realizer el procedimiento de eliminacion gaussina para obtener los valores que son necesarios. Y almacenarlos en la variable corrrespondiente
        void Calcula();

};

//=i
//Connstructor vacio del objeto.
Gauss::Gauss()
{
    for(int i=0;i<4;i++)
    {
        for(int j=0;j<5;j++)
        {
            m[i][j] = 0.0;
        }
    }
    dB0 = 0.0;
    dB1 = 0.0;
    dB2 = 0.0;
    dB3 = 0.0;
}

//=i
//Funcion para setear los datos que se usaran en la matriz.
//Se mandan las sumatorias y se llenan las casillas de forma manual.
void Gauss::ingresaElementos(int iTamanio,double dSumatoriaWi, double dSumatoriaXi, double dSumatoriaYi, double dSumatoriaZi, double dSumatoriaWiAlCuadrado, double dSumatoriaXiAlCuadrado, double dSumatoriaYiAlCuadrado, double dSumatoriaWiPorYi, double dSumatoriaWiPorZi, double dSumatoriaWiPorXi, double dSumatoriaXiPorYi, double dSumatoriaXiPorZi, double dSumatoriaYiPorZi)
{
    m[0][0] = iTamanio;
    m[0][1] = dSumatoriaWi;
    m[0][2] = dSumatoriaXi;
    m[0][3] = dSumatoriaYi;
    m[0][4] = dSumatoriaZi;

	m[1][0] = dSumatoriaWi;
    m[1][1] = dSumatoriaWiAlCuadrado;
    m[1][2] = dSumatoriaWiPorXi;
    m[1][3] = dSumatoriaWiPorYi;
    m[1][4] = dSumatoriaWiPorZi;

	m[2][0] = dSumatoriaXi;
	m[2][1] = dSumatoriaWiPorXi;
	m[2][2] = dSumatoriaXiAlCuadrado;
	m[2][3] = dSumatoriaXiPorYi;
	m[2][4] = dSumatoriaXiPorZi;

	m[3][0] = dSumatoriaYi;
	m[3][1] = dSumatoriaWiPorYi;
	m[3][2] = dSumatoriaXiPorYi;
	m[3][3] = dSumatoriaYiAlCuadrado;
	m[3][4] = dSumatoriaYiPorZi;
}

//=i
//Esta function tiene como objetivo realizer el procedimiento de eliminacion gaussina para obtener los valores que son necesarios. Y almacenarlos en la variable corrrespondiente
void Gauss::Calcula()
{
    double aux;

    //For principal para accesar renglon por renglon.
    for(int i=0;i<4;i++)
    {
        //Nos aseguramos del valor de la diagonal principal.
        if(m[i][i]!=0)
        {
            //Aux se vuelve el inverso del pivote
            aux=1/m[i][i];
            //En este for redicimos toda la fila con base al inverso.
            for(int j=0;j<5;j++)
            {   
                m[i][j]=aux*m[i][j];
            }

            //Estos dos ciclos anidados tienen por objetivo reducir los valores. Que se tienen en las columnas.
            for(int j=0;j<4;j++)
            {
                if(j!=i)
                {
                    aux=-m[j][i];
                    for(int k=0;k<5;k++)
                    {
                        m[j][k]=m[j][k]+aux*m[i][k];
                    }
                }
            }
        }
    }

	//Variable para almacenar el valor de b0 que se calcula.
	dB0 = m[0][4];
	//Variable para almacenar el valor de b1 que se calcula.
	dB1 = m[1][4];
	//Variable para almacenar el valor de b2 que se calcula.
	dB2 = m[2][4];
	//Variable para almacenar el valor de b3 que se calcula.
	dB3 = m[3][4];
}
